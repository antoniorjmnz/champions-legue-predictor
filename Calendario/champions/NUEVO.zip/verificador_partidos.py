# verificador_partidos.py

def verificar_partidos(partidos):
    print("\n=== VERIFICANDO PARTIDOS ===\n")

    # Revisar duplicados exactos
    seen = set()
    duplicados = []
    for p in partidos:
        if p in seen:
            duplicados.append(p)
        seen.add(p)

    if duplicados:
        print("❌ DUPLICADOS EXACTOS ENCONTRADOS:", duplicados)
    else:
        print("✔ Sin duplicados exactos.")

    # Revisar ida/vuelta (invertidos)
    invertidos = []
    for local, vis in partidos:
        if (vis, local) in seen:
            invertidos.append((local, vis))

    if invertidos:
        print("❌ Partidos invertidos detectados (no debe haber ida/vuelta).")
    else:
        print("✔ Sin partidos ida/vuelta repetidos.")

    # Comprobar 4 ↓ casa / 4 ↑ fuera
    home_count = {}
    away_count = {}

    for local, visitante in partidos:
        home_count[local] = home_count.get(local, 0) + 1
        away_count[visitante] = away_count.get(visitante, 0) + 1

    errores = []
    for equipo in home_count:
        if home_count[equipo] != 4 or away_count[equipo] != 4:
            errores.append(equipo)

    if errores:
        print("❌ Equipos con mal reparto:", errores)
    else:
        print("✔ Todos los equipos tienen 4 casa / 4 fuera.")

    print("\n=== FIN DE VERIFICACIÓN ===")
