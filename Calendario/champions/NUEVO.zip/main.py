# main.py
"""Punto de entrada limpio para el TFG: ejecuta el sorteo y muestra resultados finales."""

from solver import search
from state import teams, adj
from fixtures import generar_partidos_unicos, asignar_local_visitante
from verificar_calendario import verificar_calendario




def main():
    print("Generando sorteo...")

    teams = TEAMS
    adjacency_copy = {k: v[:] for k, v in adjacency.items()}

    # 1) Buscar solución de rivales
    state, rivales = search(teams, adjacency_copy)
    print(f"¿Solución encontrada?: {state is not None}")
    if state is None:
        return

    # 2) (Opcional) chequeo de restricciones
    check_all_constraints(teams, rivales)

    # 3) Generar los 144 partidos sin orientar
    partidos_sin_orientar = generar_partidos_unicos(rivales)

    # 4) Asignar local / visitante equilibrado
    partidos_finales = asignar_local_visitante(partidos_sin_orientar)

    # 5) Verificar calendario
    teams_by_name = {t.name: t for t in teams}
    verificar_calendario(partidos_finales, teams_by_name)

    # 6) Imprimir lista final
    print("\n==============================")
    print("     LISTA FINAL DE PARTIDOS")
    print("==============================\n")
    for local, visitante in partidos_finales:
        print(f"{local:<22} (LOCAL)  vs  {visitante}")

if __name__ == "__main__":
    main()