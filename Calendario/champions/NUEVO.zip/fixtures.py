# fixtures.py
from state import teams, adj
import random


def generar_partidos_unicos():
    """
    Genera una única lista de emparejamientos sin ida/vuelta.
    """
    partidos = set()

    for i, rivales in enumerate(adj):
        for j in rivales:
            if i != j:
                a = teams[i].name
                b = teams[j].name
                partidos.add(tuple(sorted((a, b))))

    return list(partidos)


def asignar_local_visitante(partidos_sin_orientar, max_intentos=50_000):
    """
    Recibe una lista de partidos sin orientar [(equipoA, equipoB), ...]
    y devuelve una lista de diccionarios:
        {"local": equipoX, "visitante": equipoY}
    cumpliendo que cada equipo juegue 4 en casa y 4 fuera.
    """
    equipos = {nombre for partido in partidos_sin_orientar for nombre in partido}
    objetivo = 4  # 4 casa / 4 fuera

    def intento():
        # 1. Orientación aleatoria inicial
        partidos = []
        for a, b in partidos_sin_orientar:
            if random.random() < 0.5:
                local, visitante = a, b
            else:
                local, visitante = b, a
            partidos.append({"local": local, "visitante": visitante})

        # 2. Contadores home / away
        home = {e: 0 for e in equipos}
        away = {e: 0 for e in equipos}
        for p in partidos:
            home[p["local"]] += 1
            away[p["visitante"]] += 1

        # 3. Búsqueda local: intentar arreglar desequilibrios
        for _ in range(10_000):  # límite interno
            if all(home[e] == objetivo and away[e] == objetivo for e in equipos):
                return partidos  # éxito

            mejorado = False

            for p in partidos:
                a = p["local"]
                b = p["visitante"]

                # Caso 1: A tiene demasiadas en casa, B demasiadas fuera -> intercambiamos
                if home[a] > objetivo and away[b] > objetivo:
                    home[a] -= 1
                    away[a] += 1
                    home[b] += 1
                    away[b] -= 1
                    p["local"], p["visitante"] = b, a
                    mejorado = True

                # Caso 2: A demasiadas fuera, B demasiadas en casa -> intercambiamos
                elif away[a] > objetivo and home[b] > objetivo:
                    home[a] += 1
                    away[a] -= 1
                    home[b] -= 1
                    away[b] += 1
                    p["local"], p["visitante"] = b, a
                    mejorado = True

            if not mejorado:
                # No podemos mejorar más en este intento
                break

        # Comprobación final por si justo se equilibró al final
        if all(home[e] == objetivo and away[e] == objetivo for e in equipos):
            return partidos
        return None

    # Bucle de reintentos desde cero
    for _ in range(max_intentos):
        res = intento()
        if res is not None:
            print("✔ Local/visitante equilibrado correctamente.")
            return res

    raise RuntimeError("❌ No se pudo equilibrar local/visitante tras muchos intentos.")


def print_partidos_bonitos(partidos):
    print("\n==============================")
    print("     LISTA FINAL DE PARTIDOS")
    print("==============================\n")

    for local, visitante in partidos:
        print(f"{local:22s} (LOCAL)  vs  {visitante}")

    print("\nTOTAL PARTIDOS:", len(partidos))
